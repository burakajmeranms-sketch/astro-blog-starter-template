# NNB GIDA Mobil Ürün Katalog Uygulaması

Bu paket, NNB GIDA için hazırlanmış ilk Flutter mobil katalog prototipidir.

## İçerik
- Fiyat göstermez.
- Sepet yoktur.
- Ödeme yoktur.
- Müşteri girişi yoktur.
- 5 örnek ürün içerir.
- Android ve iPhone için Flutter ile geliştirilmeye uygundur.

## Ekranlar
- Açılış ekranı
- Ürün listesi
- Kategori filtreleme
- Ürün arama
- Ürün detay ekranı
- İletişim ekranı

## Build için
Bilgisayarda Flutter kurulduktan sonra:

```bash
flutter create .
flutter pub get
flutter run
flutter build apk --release
```

Not: `flutter create .` komutu Android/iOS platform klasörlerini oluşturmak için kullanılır.

## Düzenlenecek alanlar
- `lib/main.dart`: Uygulama ekranları ve örnek ürünler
- `assets/nnb_logo.jpeg`: Logo
- `data/products.json`: Ürün listesinin dışa aktarılmış örneği
