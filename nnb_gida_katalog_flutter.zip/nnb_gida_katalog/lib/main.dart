import 'package:flutter/material.dart';

void main() {
  runApp(const NnbGidaApp());
}

class NnbGidaApp extends StatelessWidget {
  const NnbGidaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NNB GIDA',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.black,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F5F5),
      ),
      home: const SplashScreen(),
    );
  }
}

class Product {
  final String name;
  final String category;
  final String brand;
  final String weight;
  final String caseInfo;
  final String packageInfo;
  final String description;

  const Product({
    required this.name,
    required this.category,
    required this.brand,
    required this.weight,
    required this.caseInfo,
    required this.packageInfo,
    required this.description,
  });
}

const products = <Product>[
  Product(
    name: 'Tam Yağlı Beyaz Peynir',
    category: 'Süt Ürünleri',
    brand: 'NNB GIDA',
    weight: '1000 g',
    caseInfo: '12 adet',
    packageInfo: 'Plastik kova',
    description: 'Kahvaltı ve toplu tüketim için uygun tam yağlı beyaz peynir.',
  ),
  Product(
    name: 'Tost Kaşarı',
    category: 'Süt Ürünleri',
    brand: 'NNB GIDA',
    weight: '700 g',
    caseInfo: '16 adet',
    packageInfo: 'Vakumlu paket',
    description: 'Tost, sandviç ve sıcak servis kullanımı için uygun kaşar peyniri.',
  ),
  Product(
    name: 'Dana Fermente Sucuk',
    category: 'Şarküteri',
    brand: 'NNB GIDA',
    weight: '500 g',
    caseInfo: '20 adet',
    packageInfo: 'Vakumlu paket',
    description: 'Toptan satışa uygun, kahvaltı ve restoran kullanımı için fermente sucuk.',
  ),
  Product(
    name: 'Parmak Patates',
    category: 'Donuk Gıda',
    brand: 'NNB GIDA',
    weight: '2500 g',
    caseInfo: '4 paket',
    packageInfo: 'Donuk poşet',
    description: 'Fast food, restoran ve toplu tüketim için uygun donuk parmak patates.',
  ),
  Product(
    name: 'Ayçiçek Yağı',
    category: 'Yağlar',
    brand: 'NNB GIDA',
    weight: '5 L',
    caseInfo: '4 adet',
    packageInfo: 'Pet şişe',
    description: 'Yemek, kızartma ve profesyonel mutfak kullanımı için ayçiçek yağı.',
  ),
];

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipOval(
              child: Image.asset(
                'assets/nnb_logo.jpeg',
                width: 150,
                height: 150,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'NNB GIDA',
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Mobil Ürün Kataloğu',
              style: TextStyle(color: Colors.white70, fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedCategory = 'Tümü';
  String searchText = '';

  List<String> get categories => [
        'Tümü',
        ...{for (final product in products) product.category},
      ];

  List<Product> get filteredProducts {
    return products.where((product) {
      final matchesCategory = selectedCategory == 'Tümü' || product.category == selectedCategory;
      final query = searchText.trim().toLowerCase();
      final matchesSearch = query.isEmpty ||
          product.name.toLowerCase().contains(query) ||
          product.category.toLowerCase().contains(query) ||
          product.brand.toLowerCase().contains(query);
      return matchesCategory && matchesSearch;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final list = filteredProducts;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
              decoration: const BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      ClipOval(
                        child: Image.asset(
                          'assets/nnb_logo.jpeg',
                          width: 58,
                          height: 58,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'NNB GIDA',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1,
                              ),
                            ),
                            SizedBox(height: 3),
                            Text(
                              'Fiyatsız toptan ürün kataloğu',
                              style: TextStyle(color: Colors.white70, fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    onChanged: (value) => setState(() => searchText = value),
                    decoration: InputDecoration(
                      hintText: 'Ürün ara...',
                      prefixIcon: const Icon(Icons.search),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 58,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                scrollDirection: Axis.horizontal,
                itemCount: categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final category = categories[index];
                  final isSelected = category == selectedCategory;
                  return ChoiceChip(
                    selected: isSelected,
                    label: Text(category),
                    onSelected: (_) => setState(() => selectedCategory = category),
                    selectedColor: Colors.black,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : Colors.black87,
                      fontWeight: FontWeight.w700,
                    ),
                    side: BorderSide(color: isSelected ? Colors.black : Colors.black12),
                  );
                },
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                itemCount: list.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  return ProductCard(product: list[index]);
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Ürünler'),
          NavigationDestination(icon: Icon(Icons.call_outlined), label: 'İletişim'),
        ],
        onDestinationSelected: (index) {
          if (index == 1) {
            Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ContactScreen()));
          }
        },
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;

  const ProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product)),
      ),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 74,
              height: 74,
              decoration: BoxDecoration(
                color: const Color(0xFFEDEDED),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Icon(Icons.fastfood_rounded, size: 36, color: Colors.black54),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 6),
                  Text(product.category, style: const TextStyle(color: Colors.black54)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    children: [
                      MiniInfo(text: product.weight),
                      MiniInfo(text: 'Koli: ${product.caseInfo}'),
                    ],
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded),
          ],
        ),
      ),
    );
  }
}

class ProductDetailScreen extends StatelessWidget {
  final Product product;

  const ProductDetailScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(product.name)),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            height: 210,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(28),
            ),
            child: const Center(
              child: Icon(Icons.fastfood_rounded, color: Colors.white, size: 74),
            ),
          ),
          const SizedBox(height: 20),
          Text(product.name, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(product.description, style: const TextStyle(fontSize: 16, height: 1.45, color: Colors.black87)),
          const SizedBox(height: 22),
          DetailRow(title: 'Kategori', value: product.category),
          DetailRow(title: 'Marka', value: product.brand),
          DetailRow(title: 'Gramaj', value: product.weight),
          DetailRow(title: 'Koli içi', value: product.caseInfo),
          DetailRow(title: 'Ambalaj', value: product.packageInfo),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFEFEFEF),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text(
              'Bu katalogda fiyat bilgisi gösterilmez. Detaylı bilgi için NNB GIDA ile iletişime geçiniz.',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('İletişim')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Center(
            child: ClipOval(
              child: Image.asset('assets/nnb_logo.jpeg', width: 120, height: 120, fit: BoxFit.cover),
            ),
          ),
          const SizedBox(height: 18),
          const Center(
            child: Text('NNB GIDA', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(height: 28),
          const ContactTile(icon: Icons.phone, title: 'Telefon', value: 'Telefon numarası eklenecek'),
          const ContactTile(icon: Icons.chat, title: 'WhatsApp', value: 'WhatsApp numarası eklenecek'),
          const ContactTile(icon: Icons.location_on, title: 'Adres', value: 'Adres bilgisi eklenecek'),
          const ContactTile(icon: Icons.schedule, title: 'Çalışma Saatleri', value: 'Çalışma saatleri eklenecek'),
        ],
      ),
    );
  }
}

class MiniInfo extends StatelessWidget {
  final String text;

  const MiniInfo({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF0F0F0),
        borderRadius: BorderRadius.circular(100),
      ),
      child: Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}

class DetailRow extends StatelessWidget {
  final String title;
  final String value;

  const DetailRow({super.key, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Expanded(child: Text(title, style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w700))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class ContactTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const ContactTile({super.key, required this.icon, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.black),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(value, style: const TextStyle(color: Colors.black54)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
